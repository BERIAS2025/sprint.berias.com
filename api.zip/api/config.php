<?php
/**
 * BERIAS API Configuration
 * Keep this file private — do not commit to version control.
 */
define('CLAUDE_API_KEY', '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');
